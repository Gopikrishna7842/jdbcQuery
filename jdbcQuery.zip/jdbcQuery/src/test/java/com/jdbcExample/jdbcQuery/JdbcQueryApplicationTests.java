package com.jdbcExample.jdbcQuery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
