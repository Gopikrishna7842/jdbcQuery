package com.jdbcExample.jdbcQuery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcQueryApplication.class, args);
	}

}
